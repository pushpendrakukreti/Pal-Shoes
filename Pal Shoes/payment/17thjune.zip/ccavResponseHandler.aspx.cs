﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Collections.Specialized;
using CCA.Util;
using System.Data;
using System.Configuration;

public partial class ResponseHandler : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //string workingKey = "";//put in the 32bit alpha numeric key in the quotes provided here
        //CCACrypto ccaCrypto = new CCACrypto();
        //string encResponse = ccaCrypto.Decrypt(Request.Form["encResp"], workingKey);
        //NameValueCollection Params = new NameValueCollection();
        //string[] segments = encResponse.Split('&');
        //foreach (string seg in segments)
        //{
        //    string[] parts = seg.Split('=');
        //    if (parts.Length > 0)
        //    {
        //        string Key = parts[0].Trim();
        //        string Value = parts[1].Trim();
        //        Params.Add(Key, Value);
        //    }
        //}

        //for (int i = 0; i < Params.Count; i++)
        //{
        //    Response.Write(Params.Keys[i] + " = " + Params[i] + "<br>");
        //}

        if (!IsPostBack)
        {
            string WorkingKey = ConfigurationManager.AppSettings["WorkingKey"]; // PROVIDED BY ccAvenue
            CCACrypto func = new CCACrypto();
            string encResponse = Request.Form.ToString();

            NameValueCollection Params = new NameValueCollection();
            string[] segments = encResponse.Split('&');
            foreach (string seg in segments)
            {
                string[] parts = seg.Split('=');
                if (parts.Length > 0)
                {
                    string Key = parts[0].Trim();
                    string Value = parts[1].Trim();
                    
                    Params.Add(Key, Value);
                }
            }

            try
            {
                //Verify with ccAvenue


                string strVerify = func.verifychecksum(Params["Merchant_Id"].ToString(), Params["Order_Id"].ToString(), Params["Amount"].ToString(), Params["AuthDesc"].ToString(), WorkingKey, Params["Checksum"].ToString());

                if (strVerify.ToUpper() == "TRUE")
                {
                    if (Session["TotalAmount"].ToString() != null)
                    {
                        // UPDATE THE PAYMENT STATUS IN DB

                        //Update the Payment Status in DB
                        if (Params["AuthDesc"].ToString() == "Y")

                            Response.Redirect("http://dthindiastore.com/order-complete.aspx", false);
                        else
                            Response.Redirect("http://dthindiastore.com/404.html", false);

                        // REDIRECT TO SUCCESS PAGE OR SHOW THE PAYMENT RESPONSE ON SAME PAGE

                    }
                    else
                    {
                        Response.Redirect("http://dthindiastore.com/404.html", false);
                        // PAYMENT IS FAIL
                        // REDIRECT TO ERROR PAGE
                    }

                }
                else
                {
                    Response.Redirect("http://dthindiastore.com/404.html", false);
                    // PAYMENT VERIFICATION IS FAILED
                    // REDIRECT TO ERROR PAGE
                }
            }
            catch (Exception ex)
            {
                // ERROR IN PROCESSING
                // REDIRECT TO ERROR PAGE
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }

        }
    }
}